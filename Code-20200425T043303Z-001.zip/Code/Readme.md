

------------------------------------------------------------------------------------------------
TASK 1 & 2
------------------------------------------------------------------------------------------------
group_project_task12.ipynb is the file that can be used for testing task1,2
------------------------------------------------------------------------------------------------
TASK 3
------------------------------------------------------------------------------------------------
Task 3 we got 2 files. Task_3_centroid.ipynb is the file that can be used for testing task3 with centroid method. task_3_clustering.ipynb is the file that can be used for testing task3 with clustering method.
# Supporting Class files 
------------------------------------------------------------------------------------------------
Few functions are imported from the below python Class files so these files should be placed in the execution path.
1.centroiddetails.py
2.trackedids.py
3.yolodetection.py

# Supporting Configuration Files
------------------------------------------------------------------------------------------------
coco.names
yolov3.cfg
yolov3.weights (Since the file is huge, sharing the google drive path - https://drive.google.com/open?id=1ZJMb-Ulnqp7bu4zP7YeKFavoaK-XCUyF)

# File path Configuration
------------------------------------------------------------------------------------------------
Set Configuration file path in yolodetection.py. Change the below 

classesFile = <<coco.names>>
modelConf = <<yolov3.cfg>>
modelWeights = <<yolov3.weights>>

Change the below directory path in the group_project_task12 File

# Given Image files directory
img_sequence_dir = <<sequence_imgs>>

# Task1 
# Output Image files directory
task1_output_img_dir = <<task_1_out_images>>
# Output Video file directory
task1_video_dir = <<task_1_video.avi>>

#Task2 
# Output Image files directory
task2_output_img_dir = <<task_2_out_images>>
# Output Video file directory
task2_video_dir = <<task_2_video.avi>>

#Task3
# Output Image files directory for centroid
task3_output_img_dir = <<task_3_out_images_centroid>>
# Output Image files directory for clustering
task3_output_img_dir = <<task_3_out_images_clustering>>
# Output Video file directory for clustering
task3_video_dir = '<<task_3_clustering.avi>>
# Output Video file directory for centroid
task3_video_dir = '<<Task_3_centroid.avi>>


# Task Details
------------------------------------------------------------------------------------------------
# Task 1
Output : Outputs a video file that shows the trajectory and the total pedestrian count using Yolo and Centroid based method

# Task 2
Input : provide the dimension for the bounding box (Optional)
Output : Outputs a video file that shows the total pedestrian who entered and exited the box using Yolo and Centroid based method

-------------------------------------------------------------------------------------------------
# Task 3
Method 1: Centroid

We got 2 section of code
Section 1: will generate image frames with group and single predestions count using centroid and Euclidean distance method
Section 2: will generate the video out of the image frames

Method 2: Clustering

We got 2 section of code
Section 1: will generate image frames with group and single predestions count using Clustering method
Section 2: will generate the video out of the image frames

# Also Including the files of different other methods that we tried
------------------------------------------------------------------------------------------------
 # Image Subtraction Method for detection
 Image_Subtraction_Algo_Detection.pynb

 # Haar Cascades and Contour detection
 Haar based detector.ipynb
 Contour Detection.ipynb
 
 # Hog SVM NMS detection
 Hog_svm.py
 nms.py