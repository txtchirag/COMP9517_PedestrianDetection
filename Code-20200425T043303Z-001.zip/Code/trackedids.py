# Tracks the pedestrian ID, cebtroids and flag to indicated if the pedestrian entered the bound box or not 

class TrackedIDs:
	def __init__(self, ID, centroid):
		self.ID = ID  # unique ID to track the pedestrians
		self.centroids = [centroid] # centroid list of the pedestrian when he moves
		self.flagged = False # if pedestrian enters the bounding flagged is set to true (Task 2)