import cv2 as cv
import numpy as np 

class YoloDetection:
  def __init__(self,confThreshold=0.65,nmsThreshold=.40,inpWidth=576,inpHeight=768):
    self.confThreshold = confThreshold
    self.nmsThreshold = nmsThreshold
    self.inpWidth = inpWidth
    self.inpHeight = inpHeight
    self.classesFile = "/content/drive/My Drive/CV_YOLO/coco.names"
    self.classes = None
    with open(self.classesFile,'rt') as f:
      self.classes = f.read().rstrip('\n').split('\n')
    self.modelConf = '/content/drive/My Drive/CV_YOLO/yolov3.cfg'
    self.modelWeights = '/content/drive/My Drive/CV_YOLO/yolov3.weights'
    self.net = cv.dnn.readNetFromDarknet(self.modelConf, self.modelWeights)
    self.net.setPreferableBackend(cv.dnn.DNN_BACKEND_OPENCV)
    self.net.setPreferableTarget(cv.dnn.DNN_TARGET_CPU)

  def getOutputsNames(self): # Fetch output layer names that has unconnected o/p
    layersNames = self.net.getLayerNames()
    return [layersNames[i[0] - 1] for i in self.net.getUnconnectedOutLayers()]

  def boundingBoxList(self,frame):
    rgb = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
    object_box_dim = []
    blob = cv.dnn.blobFromImage(frame, 1/255, (self.inpWidth, self.inpHeight), [0,0,0], 1, crop = False)
    self.net.setInput(blob)
    outs = self.net.forward (self.getOutputsNames())
    frameHeight = frame.shape[0]
    frameWidth = frame.shape[1]
    classIDs = []
    confidences = []
    boxes = []

    for out in outs:
      for detection in out:            
        scores = detection [5:]
        classID = np.argmax(scores)
        confidence = scores[classID]
        if confidence > self.confThreshold:
          centerX = int(detection[0] * frameWidth)
          centerY = int(detection[1] * frameHeight)
          width = int(detection[2]* frameWidth)
          height = int(detection[3]*frameHeight )
          left = int(centerX - width/2)
          top = int(centerY - height/2)
          classIDs.append(classID)
          confidences.append(float(confidence))
          boxes.append([left, top, width, height])
    indices = cv.dnn.NMSBoxes (boxes,confidences, self.confThreshold, self.nmsThreshold )

    for i in indices:
      i = i[0]
      box = boxes[i]
      startX = box[0]
      startY = box[1]
      endX = box[2] + box[0]
      endY = box[3] + box[1]
      classId = classIDs[i]
      conf = confidences[i]
      label = '%.2f' % conf
      if self.classes:
        assert (classId < len(self.classes))
        label = '%s:%s' % (self.classes[classId], label)
      if label.startswith('person'):        
        object_box_dim.append((startX, startY, endX, endY))
        cv.rectangle(frame, (startX, startY), (endX, endY), (255, 0, 0), 1)
    return object_box_dim