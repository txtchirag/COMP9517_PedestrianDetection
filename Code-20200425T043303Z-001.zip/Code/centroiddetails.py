import numpy as np
from collections import OrderedDict
from scipy.spatial import distance as dist 

class CentroidDetails:
	def __init__(self, max_dist_apart=100, max_obj_retention=150):
		self.nextObjectID = 1  #Start with object ID 1
		self.skip_count = 0 #Frame skip count
		self.max_obj_retention = max_obj_retention #Max frames the object needs to be retained
		self.max_dist_apart = max_dist_apart #Max distance the pedestrian can walk btw frames
		self.objects = OrderedDict() # tracks the objects
		self.obj_missing_info = OrderedDict() #tracks the num of frame for which the object is missing on frame

	def add_object(self, centroid):
		self.objects[self.nextObjectID] = centroid #saving centroid along with an unique id
		self.obj_missing_info[self.nextObjectID] = 0 #Num of frame the object disappered is set to 0
		self.nextObjectID += 1  #the object ID is incremented for next object

	def delete_object(self, objectID):
		del self.objects[objectID] #delete the object from object list
		del self.obj_missing_info[objectID] #delete the object from missing list

	def update(self, bounding_boxes):
		currentCentroids = np.zeros((len(bounding_boxes), 2), dtype="int")
        # For each bounding boxes find centroid 
		for (i, (x_axis_start, y_axis_start, x_axis_end, y_axis_end)) in enumerate(bounding_boxes):
			c_axis_x = int((x_axis_start + x_axis_end) / 2.0)
			c_axis_y = int((y_axis_start + y_axis_end) / 2.0)
			currentCentroids[i] = (c_axis_x, c_axis_y)
        # If there are no objects, directly add objects to the list
		if len(self.objects) == 0:
			for i in range(0, len(currentCentroids)):
				self.add_object(currentCentroids[i])
		else:
			objectIDs = list(self.objects.keys())
			savedCentroids = list(self.objects.values())
            # If the num of centroids in the previous and current frames are not same, Skip it
            # Can only skip 2 frames consecutively
			if(len(savedCentroids)!=len(currentCentroids)): 
				self.skip_count = self.skip_count+1
				if self.skip_count < 2:
					return (0,self.nextObjectID-1) 
				else:
					self.skip_count = 0  #re-setting the skip count to zero    
      # Calculate the distance between each centroid from saved frame with current frame 
			# Rows are the centroid from previous/saved frame
      # Columns are the centroid from current frame 
			Distance_matrix = dist.cdist(np.array(savedCentroids), currentCentroids)
      # Save the one which has the smallest distance btw the current and previous centroids
			rows = Distance_matrix.min(axis=1).argsort()
			cols = Distance_matrix.argmin(axis=1)[rows]
			usedRows = set()
			usedCols = set()

			for (row, col) in zip(rows, cols):
				if row in usedRows or col in usedCols:
          # If the centroid is already used ignore
					continue
        # Check if the distance is lesser than the max distance a pedestrian can jump from one frame to another
				if Distance_matrix[row, col] > self.max_dist_apart:
					continue
        # Mapping the centroid of current frame to the object ID 
				objectID = objectIDs[row]
				self.objects[objectID] = currentCentroids[col]
				self.obj_missing_info[objectID] = 0
				usedRows.add(row)
				usedCols.add(col)
			unusedRows = set(range(0, Distance_matrix.shape[0])).difference(usedRows)
			unusedCols = set(range(0, Distance_matrix.shape[1])).difference(usedCols)
      #if the previous frame had more/equal num of centroid than the current frame
			if Distance_matrix.shape[0] >= Distance_matrix.shape[1]: 
				unusedRows = set(range(0, Distance_matrix.shape[0])).difference(usedRows)
				unusedCols = set(range(0, Distance_matrix.shape[1])).difference(usedCols)        
				if len(unusedCols)!=0:
					for col in usedCols:
						for i in range(len(savedCentroids)):
							Distance_matrix[i][col] = 2000 # setting the distance value to the max so that it gets ignored
					rows = Distance_matrix.min(axis=1).argsort()
					cols = Distance_matrix.argmin(axis=1)[rows]
					for (row, col) in zip(rows, cols):
						if row in usedRows or col in usedCols:
							continue
						if Distance_matrix[row, col] > 90: #If its not along the border do not delete
							continue
            # mapping the centroid to the objectID
						objectID = objectIDs[row]
						self.objects[objectID] = currentCentroids[col]
						self.obj_missing_info[objectID] = 0
						usedRows.add(row)
						usedCols.add(col)
				unusedRows = set(range(0, Distance_matrix.shape[0])).difference(usedRows)
				unusedCols = set(range(0, Distance_matrix.shape[1])).difference(usedCols)  
				if len(unusedCols)!=0: # if there are still centroid left from the current frame
					for col in unusedCols:    
            #add ro the object list with a new unique  id       
						self.add_object(currentCentroids[col])
						usedCols.add(col)
				for row in unusedRows:
					objectID = objectIDs[row]
					self.obj_missing_info[objectID] += 1
					if self.obj_missing_info[objectID] > self.max_obj_retention or savedCentroids[row][0]<20 or savedCentroids[row][0]>725 or savedCentroids[row][1] <30 or savedCentroids[row][1]>480:
						self.delete_object(objectID)
			else:
				for col in unusedCols:
          # If along the borders, add the object to list
					if(currentCentroids[col][0])<20 or currentCentroids[col][0] >740 or currentCentroids[col][1] <80 or currentCentroids[col][1]>480:
						self.add_object(currentCentroids[col])
						usedCols.add(col)
					else:
						continue
				unusedRows = set(range(0, Distance_matrix.shape[0])).difference(usedRows)
				unusedCols = set(range(0, Distance_matrix.shape[1])).difference(usedCols)        
				if len(unusedCols)!=0:
					for col in usedCols:
						for i in range(len(savedCentroids)):
							Distance_matrix[i][col] = 2000 # setting it to a higher value so that these values gets ignored
					rows = Distance_matrix.min(axis=1).argsort()
					cols = Distance_matrix.argmin(axis=1)[rows]
					for (row, col) in zip(rows, cols):
						if row in usedRows or col in usedCols:
							continue
						if Distance_matrix[row, col] > 90:
							continue
						objectID = objectIDs[row]
						self.objects[objectID] = currentCentroids[col]
						self.obj_missing_info[objectID] = 0
						usedRows.add(row)
						usedCols.add(col)
				unusedRows = set(range(0, Distance_matrix.shape[0])).difference(usedRows)
				unusedCols = set(range(0, Distance_matrix.shape[1])).difference(usedCols)  
				if len(unusedCols)!=0: # if still there are centroid left in the current frame, add it
					for col in unusedCols:          
						self.add_object(currentCentroids[col])
						usedCols.add(col)
		return (self.objects,self.nextObjectID-1)